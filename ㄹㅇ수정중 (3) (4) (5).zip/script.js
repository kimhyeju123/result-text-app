document.addEventListener('DOMContentLoaded', () => {
    // DOM 요소 캐싱
    const categoryList = document.getElementById('category-list');
    const opinionList = document.getElementById('opinion-list');
    const addCategoryBtn = document.getElementById('add-category-btn');
    const addOpinionBtn = document.getElementById('add-opinion-btn');
    const searchOpinionInput = document.getElementById('search-opinion');
    const summaryTextarea = document.getElementById('summary-text');
    const copySummaryBtn = document.getElementById('copy-summary-btn');
    const clearSummaryBtn = document.getElementById('clear-summary-btn');
    const modalBackdrop = document.getElementById('modal-backdrop');
    const notificationContainer = document.getElementById('notification-container');

    // 카테고리 모달 요소
    const categoryModal = document.getElementById('category-modal');
    const categoryNameInput = document.getElementById('category-name');
    const categoryIdInput = document.getElementById('category-id');
    const saveCategoryBtn = document.getElementById('save-category-btn');
    const cancelCategoryBtn = document.getElementById('cancel-category-btn');

    // 소견 모달 요소
    const opinionModal = document.getElementById('opinion-modal');
    const opinionTitleInput = document.getElementById('opinion-title');
    const opinionCategorySelect = document.getElementById('opinion-category');
    const opinionContentTextarea = document.getElementById('opinion-content');
    const opinionIdInput = document.getElementById('opinion-id');
    const saveOpinionBtn = document.getElementById('save-opinion-btn');
    const cancelOpinionBtn = document.getElementById('cancel-opinion-btn');
    const deleteOpinionInModalBtn = document.getElementById('delete-opinion-in-modal-btn');

    // 즐겨찾기 토글
    const showFavoritesCheckbox = document.getElementById('show-favorites');

    // Excel import/export
    const importExcelBtn = document.getElementById('import-excel-btn');
    const exportExcelBtn = document.getElementById('export-excel-btn');
    const importExcelInput = document.getElementById('import-excel');

    // Memo app elements
    const toggleMemoBtn = document.getElementById('toggle-memo');
    const memoApp = document.getElementById('memo-app');
    const newMemoTextarea = document.getElementById('new-memo-text');
    const addNewMemoBtn = document.getElementById('add-new-memo-btn');
    const memosContainer = document.getElementById('memos-container');


    // 데이터 스토리지 (localStorage)
    let categories = JSON.parse(localStorage.getItem('categories')) || [];
    let opinions = JSON.parse(localStorage.getItem('opinions')) || [];
    let memos = JSON.parse(localStorage.getItem('memos')) || [];
    let currentCategoryId = null; // 현재 선택된 카테고리 ID (null은 '모든 카테고리'를 의미)
    // 초기 종합 소견 내용 불러오기
    const savedSummary = localStorage.getItem('summaryContent');
    summaryTextarea.value = savedSummary || '선택한 소견들이 여기에 요약됩니다.';


    // ---- 데이터 저장 함수 ----
    function saveCategories() {
        localStorage.setItem('categories', JSON.stringify(categories));
    }

    function saveOpinions() {
        localStorage.setItem('opinions', JSON.stringify(opinions));
    }

    function saveMemos() {
        localStorage.setItem('memos', JSON.stringify(memos));
    }

    // ---- UI 렌더링 함수 ----

// ---- 카테고리 목록 렌더링 ----
function renderCategories() {
   categoryList.innerHTML = '';
   const fragment = document.createDocumentFragment();
let categoryDebounceTimeout;
addCategoryBtn.addEventListener('click', () => {
    clearTimeout(categoryDebounceTimeout);
    categoryDebounceTimeout = setTimeout(() => renderCategories(), 300);
});
        // "모든 카테고리" 옵션 추가
        const allCategoryLi = document.createElement('li');
        allCategoryLi.dataset.id = 'all'; // 특별한 ID
        allCategoryLi.textContent = '모든 카테고리';
        // 검색 중이 아니거나 (검색어가 비어있을 때) '모든 카테고리'가 선택되어 있다면 'selected' 클래스 추가
        allCategoryLi.classList.toggle('selected', searchOpinionInput.value.trim() === '' && (currentCategoryId === null || currentCategoryId === 'all'));
        allCategoryLi.addEventListener('click', () => {
            currentCategoryId = null; // 모든 카테고리를 의미
            searchOpinionInput.value = ''; // 카테고리 선택 시 검색창 초기화
            showFavoritesCheckbox.checked = false; // 카테고리 선택 시 즐겨찾기 필터 해제
            renderCategories();// 카테고리 다시 그리기
            renderOpinions(); // 전체 소견 렌더링
        });
        fragment.appendChild(allCategoryLi);

   // 일반 카테고리 항목들 렌더링
   categories.forEach(category => {
      const li = document.createElement('li');
      li.dataset.id = category.id;
      li.textContent = category.name;
      li.classList.toggle('selected', searchOpinionInput.value.trim() === '' && category.id === currentCategoryId);

      // 삭제 버튼
      const deleteBtn = document.createElement('button');
      deleteBtn.classList.add('ghost', 'small', 'delete-category-btn');
      deleteBtn.innerHTML = '<i class="fas fa-trash-alt"></i>';
      deleteBtn.title = '카테고리 삭제';
      deleteBtn.addEventListener('click', (e) => {
         e.stopPropagation(); // li 클릭 이벤트 방지
         deleteCategory(category.id);
      });
      li.appendChild(deleteBtn);


   // ✅ 더블 클릭 시 이름 수정 모달 열기
   li.addEventListener('dblclick', () => {
      showCategoryModal(category);
   });

      // 📌 카테고리 드래그 앤 드롭 이벤트 설정
      li.draggable = true;

      // 드래그 시작 시
      li.addEventListener('dragstart', (e) => {
         draggedCategory = li;
         e.dataTransfer.effectAllowed = 'move';
         e.dataTransfer.setData('text/plain', li.dataset.id);
      });

      // 다른 항목 위로 드래그 중일 때
      li.addEventListener('dragover', (e) => {
         e.preventDefault();
         const bounding = li.getBoundingClientRect();
         const offset = bounding.y + (bounding.height / 2);
         if (e.clientY < offset) {
            li.style.borderTop = '2px solid #f48fb1';
            li.style.borderBottom = 'none';
         } else {
            li.style.borderBottom = '2px solid #f48fb1';
            li.style.borderTop = 'none';
         }
      });

      // 드래그가 나갔을 때 스타일 초기화
      li.addEventListener('dragleave', () => {
         li.style.borderTop = 'none';
         li.style.borderBottom = 'none';
      });

      // 드롭 시 순서 변경 처리
      li.addEventListener('drop', (e) => {
         e.preventDefault();
         li.style.borderTop = 'none';
         li.style.borderBottom = 'none';

         const draggedId = draggedCategory.dataset.id;
         const targetId = li.dataset.id;

         const draggedIndex = categories.findIndex(c => c.id === draggedId);
         const targetIndex = categories.findIndex(c => c.id === targetId);

         if (draggedIndex > -1 && targetIndex > -1) {
            const [removed] = categories.splice(draggedIndex, 1);
            const bounding = li.getBoundingClientRect();
            const offset = bounding.y + (bounding.height / 2);
            if (e.clientY < offset) {
               categories.splice(targetIndex, 0, removed);
            } else {
               categories.splice(targetIndex + 1, 0, removed);
            }
            saveCategories(); // 저장
            renderCategories(); // 카테고리 다시 그림
            renderOpinions(); // 소견도 다시 그림
            showNotification('카테고리 순서가 변경되었습니다.', 'info');
         }

         draggedCategory = null;
      });

      fragment.appendChild(li);
   });

   categoryList.appendChild(fragment);

   // 소견 등록 모달용 셀렉트 박스도 갱신
   updateOpinionCategorySelect();
}

let draggedCategory = null;

categoryList.addEventListener('dragend', () => {
   draggedCategory = null;
   const allLis = categoryList.querySelectorAll('li');
   allLis.forEach(li => {
      li.style.borderTop = 'none';
      li.style.borderBottom = 'none';
   });
});

    function renderOpinions() {
        opinionList.innerHTML = '';

        const searchTerm = searchOpinionInput.value.toLowerCase().trim();
        let displayOpinions = [];

        if (searchTerm) {
            // 검색어가 있으면 모든 소견을 대상으로 검색 (카테고리, 즐겨찾기 필터 무시)
            displayOpinions = opinions.filter(opinion =>
                opinion.title.toLowerCase().includes(searchTerm) ||
                opinion.content.toLowerCase().includes(searchTerm)
            );
            // 검색 중일 때는 카테고리 목록의 선택 상태를 변경하지 않음.
            // renderCategories()는 여기서 호출하지 않습니다.
        } else {
            // 검색어가 없으면 현재 선택된 카테고리 + 즐겨찾기 필터 적용
            displayOpinions = opinions.filter(op =>
                (currentCategoryId === null || currentCategoryId === 'all' || op.categoryId === currentCategoryId) &&
                (!showFavoritesCheckbox.checked || op.isFavorite)
            );
            renderCategories(); // 검색어가 없을 때 카테고리 선택 상태를 올바르게 표시
        }

        const fragment = document.createDocumentFragment();

        displayOpinions.forEach(opinion => {
            const li = document.createElement('li');
            li.dataset.id = opinion.id;
            li.draggable = true;

            // 소견의 카테고리 이름을 찾음
            const category = categories.find(cat => cat.id === opinion.categoryId);
            const categoryName = category ? category.name : '미분류';

            let highlightedTitle = opinion.title;
            let highlightedContent = opinion.content; // 툴팁에 사용될 내용

            if (searchTerm) {
                const regex = new RegExp(searchTerm, 'gi');
                highlightedTitle = highlightedTitle.replace(regex, '<span class="highlighted">$&</span>');
                highlightedContent = highlightedContent.replace(regex, '<span class="highlighted">$&</span>');
                li.classList.add('searching'); // 검색 중임을 나타내는 클래스 추가 (CSS에서 활용 가능)
            } else {
                li.classList.remove('searching');
            }


            li.innerHTML = `
                <div class="opinion-header">
                    <span class="opinion-title-text">${highlightedTitle}</span>
                    <div class="opinion-buttons">
                        <button class="ghost small favorite-opinion-btn" data-id="${opinion.id}" title="${opinion.isFavorite ? '즐겨찾기 해제' : '즐겨찾기'}"><i class="${opinion.isFavorite ? 'fas' : 'far'} fa-heart"></i></button>
                        <button class="ghost small edit-opinion-btn" data-id="${opinion.id}" title="소견 수정"><i class="fas fa-edit"></i></button>
                    </div>
                    <div class="tooltip">${highlightedContent}</div>
                </div>
            `;

// 👁 미리보기 아이콘 + 툴팁 고정 기능
const buttonsDiv = li.querySelector('.opinion-buttons');
const tooltip = li.querySelector('.tooltip');
const viewIconBtn = document.createElement('button');
viewIconBtn.classList.add('ghost', 'small', 'view-opinion-btn');
viewIconBtn.innerHTML = `<i class="fas fa-eye"></i>`;
viewIconBtn.title = '내용 미리보기';
buttonsDiv.appendChild(viewIconBtn);

let tooltipFixed = false;

viewIconBtn.addEventListener('mouseenter', () => {
   if (!tooltipFixed) {
      tooltip.style.opacity = '1';
      tooltip.style.visibility = 'visible';
   }
});

viewIconBtn.addEventListener('mouseleave', () => {
   if (!tooltipFixed) {
      tooltip.style.opacity = '0';
      tooltip.style.visibility = 'hidden';
   }
});

viewIconBtn.addEventListener('click', (e) => {
   e.stopPropagation();

   // ✅ 모든 툴팁과 아이콘의 고정 상태 초기화
   document.querySelectorAll('.tooltip').forEach(t => {
      if (t !== tooltip) {
         t.style.opacity = '0';
         t.style.visibility = 'hidden';
      }
   });
   document.querySelectorAll('.view-opinion-btn.active').forEach(btn => {
      if (btn !== viewIconBtn) {
         btn.classList.remove('active');
         btn.dataset.fixed = 'false';
      }
   });

   // ✅ 현재 아이콘 토글 처리
   tooltipFixed = !viewIconBtn.classList.contains('active');

   if (tooltipFixed) {
      tooltip.style.opacity = '1';
      tooltip.style.visibility = 'visible';
      viewIconBtn.classList.add('active');
   } else {
      tooltip.style.opacity = '0';
      tooltip.style.visibility = 'hidden';
      viewIconBtn.classList.remove('active');
   }
});


            // 더블 클릭으로 종합 소견에 추가 (알림 없음)
            li.addEventListener('dblclick', (event) => {
                const targetLi = event.target.closest('li');
                if (targetLi && targetLi.dataset.id) {
                    const clickedOpinion = opinions.find(op => op.id === targetLi.dataset.id);
                    if (clickedOpinion && clickedOpinion.content) {
                        addOpinionToSummary(clickedOpinion.content);
                        copySummary(); // 알림 없이 복사만 실행
                    }
                }
            });

            // 단일 클릭 시 해당 소견의 카테고리 활성화 로직 추가
            li.addEventListener('click', (event) => {
                const targetLi = event.target.closest('li');
                // 버튼 클릭은 제외
                if (!targetLi || event.target.closest('button')) {
                    return;
                }

                const clickedOpinion = opinions.find(op => op.id === targetLi.dataset.id);
                if (clickedOpinion && clickedOpinion.categoryId) {
                    currentCategoryId = clickedOpinion.categoryId; // 클릭된 소견의 카테고리를 현재 선택 카테고리로 설정
                    searchOpinionInput.value = ''; // 검색창 초기화
                    showFavoritesCheckbox.checked = false; // 즐겨찾기 필터 해제
                    renderCategories(); // 카테고리 목록을 다시 렌더링하여 선택 상태 업데이트
                    renderOpinions(); // 소견 목록도 다시 렌더링 (현재 선택된 카테고리에 맞춰)
                }
            });


            // 드래그 앤 드롭 이벤트 리스너 추가
            li.addEventListener('dragstart', dragStart);
            li.addEventListener('dragover', dragOver);
            li.addEventListener('drop', drop);
            li.addEventListener('dragleave', dragLeave);
            li.addEventListener('dragenter', dragEnter);

            fragment.appendChild(li);
        });
        opinionList.appendChild(fragment);
    }


    function updateOpinionCategorySelect() {
        opinionCategorySelect.innerHTML = '<option value="">카테고리 선택</option>';
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            opinionCategorySelect.appendChild(option);
        });
    }

    function renderMemos() {
        memosContainer.innerHTML = '';
        memos.forEach(memo => {
            const memoItem = document.createElement('div');
            memoItem.classList.add('memo-item');
            memoItem.dataset.id = memo.id;
            memoItem.innerHTML = `
                <p>${memo.content}</p>
                <small>${new Date(memo.timestamp).toLocaleString('ko-KR')}</small>
                <div class="memo-actions">
                    <button class="ghost small edit-memo-btn" data-id="${memo.id}" title="메모 수정"><i class="fas fa-edit"></i></button>
                    <button class="ghost small delete-memo-btn" data-id="${memo.id}" title="메모 삭제"><i class="fas fa-trash-alt"></i></button>
                </div>
            `;
            memosContainer.appendChild(memoItem);
        });
    }

    // ---- 카테고리 관리 함수 ----

    function showCategoryModal(category = null) {
        if (category) {
            categoryNameInput.value = category.name;
            categoryIdInput.value = category.id;
            categoryModal.querySelector('h2').textContent = '카테고리 수정';
        } else {
            categoryNameInput.value = '';
            categoryIdInput.value = '';
            categoryModal.querySelector('h2').textContent = '새 카테고리 추가';
        }
        modalBackdrop.classList.add('active');
        categoryModal.classList.add('active');
        categoryNameInput.focus();
    }

    function hideCategoryModal() {
        modalBackdrop.classList.remove('active');
        categoryModal.classList.remove('active');
    }

    function saveCategory() {
        const name = categoryNameInput.value.trim();
        const id = categoryIdInput.value;

        if (!name) {
            showNotification('카테고리 이름을 입력하세요!', 'error');
            return;
        }

    // ✅ 이름 중복 방지 검사
   const isDuplicate = categories.some(cat =>
      cat.name === name && cat.id !== id // 자기 자신은 제외
   );

   if (isDuplicate) {
      showNotification('이미 존재하는 카테고리 이름입니다! ⚠️', 'warning');
      return;
   }
        if (id) {
            categories = categories.map(cat => cat.id === id ? { ...cat, name } : cat);
            showNotification('카테고리가 수정되었습니다! ✏️', 'success');
        } else {
            const newCategory = { id: crypto.randomUUID(), name };
            categories.push(newCategory);
            showNotification('새 카테고리가 추가되었습니다! ✨', 'success');
     
     }
        saveCategories();
        renderCategories();
        renderOpinions(); // 카테고리 추가/수정 후 소견 목록 갱신
        hideCategoryModal();
    }

    function deleteCategory(id) {
        if (confirm('이 카테고리를 삭제하면 관련된 모든 소견도 삭제됩니다. 계속하시겠습니까?')) {
            categories = categories.filter(cat => cat.id !== id);
            opinions = opinions.filter(op => op.categoryId !== id);
            saveCategories();
            saveOpinions();
            if (currentCategoryId === id) {
                currentCategoryId = null; // 삭제된 카테고리가 현재 선택된 카테고리였다면 '모든 카테고리'로 변경
            }
            renderCategories();
            renderOpinions();
            showNotification('카테고리 및 관련 소견이 삭제되었습니다! 🗑️', 'success');
        }
    }


    // ---- 소견 관리 함수 ----

    function showOpinionModal(opinion = null) {
        if (opinion) {
            opinionTitleInput.value = opinion.title;
            opinionCategorySelect.value = opinion.categoryId || '';
            opinionContentTextarea.value = opinion.content;
            opinionIdInput.value = opinion.id;
            opinionModal.querySelector('h2').textContent = '소견 수정';
            deleteOpinionInModalBtn.style.display = 'inline-flex'; // 수정 시 삭제 버튼 표시
        } else {
            opinionTitleInput.value = '';
            opinionCategorySelect.value = currentCategoryId || '';
            opinionContentTextarea.value = '';
            opinionIdInput.value = '';
            opinionModal.querySelector('h2').textContent = '새 소견 추가';
            deleteOpinionInModalBtn.style.display = 'none'; // 추가 시 삭제 버튼 숨김
        }
        modalBackdrop.classList.add('active');
        opinionModal.classList.add('active');
        opinionTitleInput.focus();
    }

    function hideOpinionModal() {
        modalBackdrop.classList.remove('active');
        opinionModal.classList.remove('active');
    }

    function saveOpinion() {
        const title = opinionTitleInput.value.trim();
        const categoryId = opinionCategorySelect.value;
        const content = opinionContentTextarea.value.trim();
        const id = opinionIdInput.value;

        if (!title || !categoryId || !content) {
            showNotification('모든 필드를 입력하세요!', 'error');
            return;
        }

        if (id) {
            opinions = opinions.map(op => op.id === id ? { ...op, title, categoryId, content } : op);
            showNotification('소견이 수정되었습니다! ✏️', 'success');
        } else {
            const newOpinion = { id: crypto.randomUUID(), title, categoryId, content, isFavorite: false };
            opinions.push(newOpinion);
            showNotification('새 소견이 추가되었습니다! ✨', 'success');
        }
        saveOpinions();
        renderOpinions();
        hideOpinionModal();
    }

    function editOpinion(id) {
        const opinionToEdit = opinions.find(op => op.id === id);
        if (opinionToEdit) {
            showOpinionModal(opinionToEdit);
        }
    }

    function deleteOpinion(id) {
        if (confirm('정말로 이 소견을 삭제하시겠습니까?')) {
            opinions = opinions.filter(op => op.id !== id);
            saveOpinions();
            renderOpinions();
            hideOpinionModal(); // 삭제 후 모달 닫기
            showNotification('소견이 삭제되었습니다! 🗑️', 'success');
        }
    }

    function toggleFavorite(id) {
        opinions = opinions.map(op => op.id === id ? { ...op, isFavorite: !op.isFavorite } : op);
        saveOpinions();
        renderOpinions();

        showNotification(opinions.find(op => op.id === id).isFavorite ? '즐겨찾기에 추가되었습니다💖' : '즐겨찾기에서 제거되었습니다🤍', 'success');
    }


    // ---- 종합 소견 관리 함수 (일반 textarea) ----

    function addOpinionToSummary(content) {
        const currentContent = summaryTextarea.value.trim();

        if (currentContent === '선택한 소견들이 여기에 요약됩니다.' || currentContent === '') {
            summaryTextarea.value = content + '\n\n';
        } else {
            if (currentContent.includes(content.trim())) {
                showNotification('이미 추가된 소견입니다!', 'info');
                return;
            }
            summaryTextarea.value += content + '\n\n';
        }
        summaryTextarea.scrollTop = summaryTextarea.scrollHeight; // 스크롤 하단으로 이동
        localStorage.setItem('summaryContent', summaryTextarea.value); // 변경 내용 저장
    }

    // copySummary 함수 수정: 알림 호출 로직 제거
    function copySummary() {
        if (summaryTextarea.value && summaryTextarea.value.trim() !== '' && summaryTextarea.value.trim() !== '선택한 소견들이 여기에 요약됩니다.') {
            return navigator.clipboard.writeText(summaryTextarea.value) // Promise를 반환하도록 return 추가
                .catch(err => {
                    console.error('클립보드 복사 실패:', err);
                    throw err; // 에러를 다시 던져서 호출자가 catch할 수 있도록
                });
        } else {
            // 복사할 내용이 없을 때는 Promise.reject를 반환하여 호출자가 .catch()를 통해 처리하도록 함
            return Promise.reject(new Error('복사할 내용이 없습니다.'));
        }
    }

    function clearSummary() {
        if (confirm('종합 소견 내용을 모두 지우시겠습니까?')) {
            summaryTextarea.value = '선택한 소견들이 여기에 요약됩니다.';
            localStorage.removeItem('summaryContent');
            showNotification('종합 소견이 초기화되었습니다! 🧹', 'success');
        }
    }

    // ---- 메모 관리 함수 ----

    function toggleMemoApp() {
        memoApp.classList.toggle('hidden');
        if (!memoApp.classList.contains('hidden')) {
            newMemoTextarea.focus();
        }
    }

    function addMemo() {
        const content = newMemoTextarea.value.trim();
        if (content) {
            const newMemo = {
                id: crypto.randomUUID(),
                content: content,
                timestamp: new Date().toISOString()
            };
            memos.push(newMemo);
            saveMemos();
            newMemoTextarea.value = '';
            renderMemos();
            showNotification('메모가 추가되었습니다! 📝', 'success');
        } else {
            showNotification('메모 내용을 입력하세요.', 'error');
        }
    }

    function editMemo(id) {
        const memoToEdit = memos.find(memo => memo.id === id);
        if (memoToEdit) {
            const newContent = prompt('메모를 수정하세요:', memoToEdit.content);
            if (newContent !== null && newContent.trim() !== '') {
                memos = memos.map(memo => memo.id === id ? { ...memo, content: newContent.trim(), timestamp: new Date().toISOString() } : memo);
                saveMemos();
                renderMemos();
                showNotification('메모가 수정되었습니다! ✏️', 'success');
            } else if (newContent !== null) {
                showNotification('메모 내용을 비워둘 수 없습니다.', 'error');
            }
        }
    }

    function deleteMemo(id) {
        if (confirm('정말로 이 메모를 삭제하시겠습니까?')) {
            memos = memos.filter(memo => memo.id !== id);
            saveMemos();
            renderMemos();
            showNotification('메모가 삭제되었습니다! 🗑️', 'success');
        }
    }

    // ---- 알림 기능 ----
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.classList.add('notification-message', type);
        notification.innerHTML = `<i class="${type === 'success' ? 'fas fa-check-circle' : type === 'error' ? 'fas fa-times-circle' : 'fas fa-info-circle'}"></i> ${message}`;
        notificationContainer.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
        }, 10);

        const currentNotificationTimeout = setTimeout(() => {
            notification.classList.remove('show');
            notification.addEventListener('transitionend', () => notification.remove(), { once: true });
        }, 2000);

        notification.addEventListener('click', () => {
            clearTimeout(currentNotificationTimeout);
            notification.classList.remove('show');
            notification.addEventListener('transitionend', () => notification.remove(), { once: true });
        });
    }

function exportToExcel() {
   if (!confirm("Excel 파일로 내보내시겠습니까?")) {
      return; // 사용자가 '취소'를 선택한 경우 중단
   }

   const dataToExport = opinions.map(op => ({
      카테고리: categories.find(cat => cat.id === op.categoryId)?.name || '없음',
      제목: op.title,
      내용: op.content,
      즐겨찾기: op.isFavorite ? 'Y' : 'N'
   }));

   if (dataToExport.length === 0) {
      showNotification('내보낼 소견 데이터가 없습니다.', 'info');
      return;
   }

   const ws = XLSX.utils.json_to_sheet(dataToExport);
   const wb = XLSX.utils.book_new();
   XLSX.utils.book_append_sheet(wb, ws, "소견 목록");
   XLSX.writeFile(wb, "소견_목록.xlsx");
   showNotification('소견 목록이 Excel로 내보내졌습니다! 📊', 'success');
}

     function importFromExcel(event) {
        const file = event.target.files[0];
        if (!file) {
            console.log('선택된 파일이 없습니다.'); // 디버깅용 로그 추가
            return;
        }
        console.log('파일이 선택되었습니다:', file.name); // 디버깅용 로그 추가

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = new Uint8Array(e.target.result);
                console.log('파일 데이터를 배열 버퍼로 읽었습니다.'); // 디버깅용 로그 추가
                const workbook = XLSX.read(data, { type: 'array' });
                console.log('워크북을 읽었습니다. 시트 이름:', workbook.SheetNames); // 디버깅용 로그 추가
                const firstSheetName = workbook.SheetNames[0];

                // 오류 발생 지점 수정: workbook 객체에서 Sheets 속성을 참조
                const worksheet = workbook.Sheets[firstSheetName];
                console.log(`첫 번째 워크시트 (${firstSheetName})를 선택했습니다.`); // 디버깅용 로그 추가

                const json = XLSX.utils.sheet_to_json(worksheet);
                console.log('워크시트를 JSON으로 변환했습니다. 데이터 (첫 5개):', json.slice(0, 5)); // 디버깅용 로그 추가

                const importedOpinions = [];
                const newCategoriesFromImport = new Set();

                json.forEach(row => {
                    const categoryName = row['카테고리'] || '기타';
                    let category = categories.find(cat => cat.name === categoryName);
                    if (!category) {
                        category = { id: crypto.randomUUID(), name: categoryName };
                        categories.push(category);
                        newCategoriesFromImport.add(category.id);
                    }

                    // 즐겨찾기 여부 처리 (위치 올바르게 이동)
                    let isFavorite = false;
                    if (row.hasOwnProperty('즐겨찾기')) { // '즐겨찾기' 컬럼이 존재하는지 확인
                        const favoriteValue = String(row['즐겨찾기']).toUpperCase().trim(); // 문자열로 변환 후 대문자, 공백 제거
                        isFavorite = favoriteValue === 'Y';
                    }

                    importedOpinions.push({
                        id: crypto.randomUUID(),
                        title: row['제목'] || '제목 없음',
                        categoryId: category.id,
                        content: row['내용'] || '',
                        isFavorite: isFavorite // 올바르게 설정된 isFavorite 변수 사용
                    });
                });
                console.log('가져온 소견 데이터 (첫 5개):', importedOpinions.slice(0, 5)); // 디버깅용 로그 추가


                if (confirm('기존 데이터를 덮어쓰시겠습니까? (취소 시 기존 데이터에 추가됩니다)')) {
                    opinions = importedOpinions;
                } else {
                    opinions.push(...importedOpinions);
                }

                saveCategories();
                saveOpinions();
                renderCategories();
                renderOpinions();

                showNotification(`${importedOpinions.length}개의 소견이 가져와졌습니다! 📥`, 'success');
                if (newCategoriesFromImport.size > 0) {
                    showNotification(`${newCategoriesFromImport.size}개의 새 카테고리가 추가되었습니다.`, 'info');
                }

            } catch (error) {
                console.error('Excel 파일 읽기 오류:', error);
                showNotification('Excel 파일을 읽는 데 실패했습니다. 올바른 형식인지 확인하세요.', 'error');
            }
        };
        reader.readAsArrayBuffer(file);
    }


    // ---- 드래그 앤 드롭 ----
    let draggedOpinion = null;

    function dragStart(e) {
        draggedOpinion = e.target;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', e.target.dataset.id);

        // 드래그 시작 시 해당 요소의 툴팁 숨기기
        const tooltip = draggedOpinion.querySelector('.tooltip');
        if (tooltip) {
            tooltip.style.display = 'none'; // 툴팁을 완전히 숨김
        }

        setTimeout(() => {
            e.target.classList.add('dragging');
        }, 0);
    }

    function dragOver(e) {
        e.preventDefault();
        const targetLi = e.target.closest('li');
        if (targetLi && targetLi !== draggedOpinion && targetLi.parentElement === opinionList) {
            const bounding = targetLi.getBoundingClientRect();
            const offset = bounding.y + (bounding.height / 2);
            if (e.clientY < offset) {
                targetLi.style.borderTop = '2px solid #f48fb1';
                targetLi.style.borderBottom = 'none';
            } else {
                targetLi.style.borderBottom = '2px solid #f48fb1';
                targetLi.style.borderTop = 'none';
            }
        }
    }

    function dragEnter(e) {
        e.preventDefault();
    }

    function dragLeave(e) {
        const targetLi = e.target.closest('li');
        if (targetLi) {
            targetLi.style.borderTop = 'none';
            targetLi.style.borderBottom = 'none';
        }
    }

    function drop(e) {
        e.preventDefault();
        draggedOpinion.classList.remove('dragging');

        const targetLi = e.target.closest('li');
        if (targetLi) {
            targetLi.style.borderTop = 'none';
            targetLi.style.borderBottom = 'none';
        }

        // 드래그가 끝난 후 (성공적으로 드롭될 경우) 툴팁 다시 표시
        if (draggedOpinion) {
            const tooltip = draggedOpinion.querySelector('.tooltip');
            if (tooltip) {
                tooltip.style.display = ''; // CSS 기본값으로 되돌림 (hover 시 표시되게)
            }
        }


        if (draggedOpinion && targetLi && draggedOpinion !== targetLi && targetLi.parentElement === opinionList) {
            const draggedId = draggedOpinion.dataset.id;
            const targetId = targetLi.dataset.id;

            const draggedIndex = opinions.findIndex(op => op.id === draggedId);
            const targetIndex = opinions.findIndex(op => op.id === targetId);

            if (draggedIndex > -1 && targetIndex > -1) {
                const [removed] = opinions.splice(draggedIndex, 1);

                const bounding = targetLi.getBoundingClientRect();
                const offset = bounding.y + (bounding.height / 2);
                if (e.clientY < offset) {
                    opinions.splice(targetIndex, 0, removed);
                } else {
                    opinions.splice(targetIndex + 1, 0, removed);
                }

                saveOpinions();
                renderOpinions();
                showNotification('소견 순서가 변경되었습니다.', 'info');
            }
        }
        draggedOpinion = null; // 드래그 완료 후 초기화
    }

    // 드래그 작업이 끝날 때 (성공/실패 무관) 툴팁을 다시 표시
    opinionList.addEventListener('dragend', (e) => {
        if (draggedOpinion) {
            const tooltip = draggedOpinion.querySelector('.tooltip');
            if (tooltip) {
                tooltip.style.display = ''; // CSS 기본값으로 되돌림
            }
            draggedOpinion.classList.remove('dragging');
            draggedOpinion = null;
        }
        // 드래그 취소 시 border 스타일 제거
        const allOpinions = opinionList.querySelectorAll('li');
        allOpinions.forEach(li => {
            li.style.borderTop = 'none';
            li.style.borderBottom = 'none';
        });
    });


    // ---- 이벤트 리스너 ----

    // 카테고리 이벤트
    addCategoryBtn.addEventListener('click', () => showCategoryModal());
    saveCategoryBtn.addEventListener('click', saveCategory);
    cancelCategoryBtn.addEventListener('click', hideCategoryModal);
    categoryList.addEventListener('click', (event) => {
        const li = event.target.closest('li');
        if (li && li.dataset.id) {
            if (!event.target.closest('button.delete-category-btn')) {
                // '모든 카테고리' 클릭 시
                if (li.dataset.id === 'all') {
                    currentCategoryId = null; // null은 모든 카테고리를 의미
                } else {
                    currentCategoryId = li.dataset.id;
                }
                searchOpinionInput.value = ''; // 카테고리 변경 시 검색창 초기화
                showFavoritesCheckbox.checked = false; // 카테고리 선택 시 즐겨찾기 필터 해제
                renderCategories();
                renderOpinions(); // 선택된 카테고리에 따라 소견 렌더링
            }
        }
    });

    // 소견 이벤트
    addOpinionBtn.addEventListener('click', () => showOpinionModal());
    saveOpinionBtn.addEventListener('click', saveOpinion);
    cancelOpinionBtn.addEventListener('click', hideOpinionModal);
    deleteOpinionInModalBtn.addEventListener('click', () => {
        const opinionId = opinionIdInput.value;
        if (opinionId) {
            deleteOpinion(opinionId);
        }
    });

    // Debounce for search input
    let searchDebounceTimeout;
    searchOpinionInput.addEventListener('input', () => {
        clearTimeout(searchDebounceTimeout);
        searchDebounceTimeout = setTimeout(() => {
            currentCategoryId = null; // 검색 시에는 카테고리 필터를 비활성화
            showFavoritesCheckbox.checked = false; // 검색 시 즐겨찾기 필터 비활성화
            renderOpinions(); // 검색어 입력 시 모든 소견을 대상으로 검색 및 렌더링
        }, 300);
    });

    // 즐겨찾기 토글 필터
    showFavoritesCheckbox.addEventListener('change', () => {
        searchOpinionInput.value = ''; // 즐겨찾기 필터 적용 시 검색창 초기화
        renderOpinions(); // 즐겨찾기 상태에 따라 소견 렌더링
    });


// 소견 목록 내 버튼 클릭 처리 (이벤트 위임)
opinionList.addEventListener('click', (event) => {
    const target = event.target;
    const favoriteBtn = target.closest('.favorite-opinion-btn');
    const editBtn = target.closest('.edit-opinion-btn');

    if (favoriteBtn) {
        event.stopPropagation(); // 이벤트 버블링 중지
        const opinionId = favoriteBtn.dataset.id;
        toggleFavorite(opinionId);
    } else if (editBtn) {
        event.stopPropagation(); // 이벤트 버블링 중지
        const opinionId = editBtn.dataset.id;
        const opinion = opinions.find(op => op.id === opinionId);
        if (opinion) {
            showOpinionModal(opinion);
        }
    }
});


    // 소견 항목 더블클릭 시 해당 소견 내용 복사 및 요약에 추가
    opinionList.addEventListener('dblclick', (event) => {
        const target = event.target;
        const opinionItem = target.closest('.opinion-item');

        if (!opinionItem) return; // 소견 항목이 아니면 무시

        // 더블클릭된 요소가 버튼이거나 버튼의 자식인지 확인하여 제외
        if (target.closest('.favorite-opinion-btn') ||
            target.closest('.edit-opinion-btn') ||
            target.closest('.view-opinion-btn')) { // 미리보기 버튼도 추가
            event.stopPropagation(); // 버튼 더블클릭 시 부모 요소로 이벤트 전파 중지
            return;
        }

        const opinionId = opinionItem.dataset.id;
        const opinion = opinions.find(o => o.id === opinionId);

        if (opinion) {
            // 소견 제목과 내용을 조합하여 문자열 생성
            const opinionContentString = `${opinion.title}\n${opinion.content}`;

            // 1. 소견을 요약에 추가
            addOpinionToSummary(opinionContentString);

            // 2. 해당 소견의 내용만 클립보드에 복사
            copyOpinionToClipboard(opinionId);
        }
    });

    // 종합 소견 이벤트
    copySummaryBtn.addEventListener('click', () => {
        copySummary()
            .then(() => showNotification('종합 소견이 클립보드에 복사되었습니다! 📋', 'success'))
            .catch(err => {
                showNotification(`클립보드 복사 실패: ${err.message}`, 'error');
            });
    });
    clearSummaryBtn.addEventListener('click', clearSummary);

    // 모달 외부 클릭 시 닫기 (backdrop) 및 ESC 키로 모달 닫기
    modalBackdrop.addEventListener('click', (event) => {
        if (event.target === modalBackdrop) {
            hideCategoryModal();
            hideOpinionModal();
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            if (categoryModal.classList.contains('active')) {
                hideCategoryModal();
            }
            if (opinionModal.classList.contains('active')) {
                hideOpinionModal();
            }
            if (!memoApp.classList.contains('hidden')) {
                toggleMemoApp();
            }
        }
    });


    // Excel 이벤트
    importExcelBtn.addEventListener('click', () => importExcelInput.click());
    importExcelInput.addEventListener('change', importFromExcel);
    exportExcelBtn.addEventListener('click', exportToExcel);
    setInterval(exportToExcel, 3600000); // 엑셀 1시간마다 자동 백업

    // Memo 앱 이벤트
    toggleMemoBtn.addEventListener('click', toggleMemoApp);
    addNewMemoBtn.addEventListener('click', addMemo);
    memosContainer.addEventListener('click', (event) => {
        const target = event.target;
        const memoItem = target.closest('.memo-item');
        if (!memoItem) return;

        const memoId = memoItem.dataset.id;

        if (target.classList.contains('edit-memo-btn')) {
            editMemo(memoId);
        } else if (target.classList.contains('delete-memo-btn')) {
            deleteMemo(memoId);
        }
    });


    // 초기 렌더링
    renderCategories();
    renderOpinions(); // 초기에 모든 소견 또는 이전에 선택된 카테고리의 소견 렌더링
    renderMemos();
});